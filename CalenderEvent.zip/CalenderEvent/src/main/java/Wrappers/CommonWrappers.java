package Wrappers;
 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class CommonWrappers {

	protected static RemoteWebDriver driver;
		
	/**
	 * This method will launch only chrome and maximise the browser and set the
	 * wait for 30 seconds and load the url
	 * @author Priyanka Komanduri
	 * 
	 */
	public void login() {
		try {
			driver = new ChromeDriver();
			driver.get("http://localhost:3000");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method will enter the value to the text field using id attribute to locate
	 * 
	 * @param idValue - id of the webelement
	 * @param data - The data to be sent to the webelement
	 * @author - Priyanka Komanduri
	 * @throws IOException 
	 * @throws COSVisitorException 
	 */
	public void enterById(String idValue, String data) {
		try {
			driver.findElement(By.id(idValue)).clear();
			driver.findElement(By.id(idValue)).sendKeys(data);	

		} catch (Exception e) {
		}
	}
	
	/**
	 * This method will enter the value to the text field using xpath attribute to locate
	 * 
	 * @param idValue - id of the webelement
	 * @param data - The data to be sent to the webelement
	 * @author - Priyanka Komanduri
	 * @throws IOException 
	 * @throws COSVisitorException 
	 */
	public void enterByXpath(String idValue, String data) {
		try {
			driver.findElement(By.xpath(idValue)).clear();
			driver.findElement(By.xpath(idValue)).sendKeys(data);	

		} catch (Exception e) {
		}
	}

	
	/**
	 * This method will verify the title of the browser 
	 * @param title - The expected title of the browser
	 * @author Priyanka Komanduri
	 */
	public void verifyTitle(String title){
		try{
			if (driver.getTitle().equalsIgnoreCase(title)){
			}

		}catch (Exception e) {
		}
	}

	/**
	 * This method will click the element using id as locator
	 * @param id  The id (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public void clickById(String id) {
		try{
			driver.findElement(By.id(id)).click();
		} catch (Exception e) {
			
		}
	}

	/**
	 * This method will click the element using id as locator
	 * @param xpath  The xpath (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public WebElement findElementByXpath(String xpath) {
		WebElement ele = null;
		try{
			 ele = driver.findElement(By.xpath(xpath));
		} catch (Exception e) {
			
		}
		return ele;
	}

	/**
	 * This method will click the element using id as locator
	 * @param xpath  The xpath (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public List<WebElement> findElementsByXpath(String xpath) {
		List<WebElement> ele = null;
		try{
			 ele = driver.findElements(By.xpath(xpath));
		} catch (Exception e) {
			
		}
		return ele;
	}

	/**
	 * This method will click the element using id as locator
	 * @param id  The id (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public void clickByClassName(String classVal) {
		try{
			driver.findElement(By.className(classVal)).click();
			} catch (Exception e) {
		}
	}
	/**
	 * This method will click the element using name as locator
	 * @param name  The name (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public void clickByName(String name) {

		try{
			driver.findElement(By.name(name)).click();
			} catch (Exception e) {
		}
	}

	/**
	 * This method will click the element using link name as locator
	 * @param name  The link name (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public void clickByLink(String name) {
		try{
			driver.findElement(By.linkText(name)).click();
		} catch (Exception e) {
			
		}
	}

	/**
	 * This method will click the element using xpath as locator
	 * @param xpathVal  The xpath (locator) of the element to be clicked
	 * @author Priyanka Komanduri
	 */
	public void clickByXpath(String xpathVal) {
		try{
			driver.findElement(By.xpath(xpathVal)).click();
		} catch (Exception e) {
			
		}
	}

	/**
	 * This method will mouse over on the element using xpath as locator
	 * @param xpathVal  The xpath (locator) of the element to be moused over
	 * @author Priyanka Komanduri
	 */
	public void mouseOverByXpath(String xpathVal) {
		try{
			new Actions(driver).moveToElement(driver.findElement(By.xpath(xpathVal))).build().perform();
					} catch (Exception e) {
		}
	}

	/**
	 * This method will mouse over on the element using link name as locator
	 * @param xpathVal  The link name (locator) of the element to be moused over
	 * @author Priyanka Komanduri
	 */
	public void mouseOverByLinkText(String linkName) {
		try{
			new Actions(driver).moveToElement(driver.findElement(By.linkText(linkName))).build().perform();
					} catch (Exception e) {
		}
	}

	public String getTextByXpath(String xpathVal){
		String txt = "";
		try{
			return driver.findElement(By.xpath(xpathVal)).getText();
		} catch (Exception e) {
			
		}
		return txt; 
	}

	/**
	 * This method will select the drop down value using id as locator
	 * @param id The id (locator) of the drop down element
	 * @param value The value to be selected (visibletext) from the dropdown 
	 * @author Priyanka Komanduri
	 */
	public void selectById(String id, String value) {
		try{
			new Select(driver.findElement(By.id(id))).selectByVisibleText(value);;
		} catch (Exception e) {

		}
	}
	
			/**
	 * This method will close all the browsers
	 * @author Priyanka Komanduri
	 */
	public void quitBrowser() {
		try {
			driver.quit();
		} catch (Exception e) {
	
		}

	}

	
}

