package StepDefinitions;

import HelperFiles.DairyView_helper;
import Wrappers.CommonWrappers;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DairyView_StepDef extends CommonWrappers {
	
	CommonWrappers com = new CommonWrappers ();
	DairyView_helper helper = new DairyView_helper();

@Given("^As an unuthenticated user launch the tiny app$")
public void unuthernticated_user_launch_the_tiny_app() throws Throwable {
    com.login();
}

@Given("^As an uthenticated user launch the tiny app$")
public void uthenticated_user_launch_the_tiny_app() throws Throwable {
    com.login();
}

//@Then("^user is able to see the app loaded successfully$")
public void user_is_able_to_see_the_app_loaded_successfully() throws Throwable {
   // helper.validateAppLoaded();
}

@Given("^user is able to see calender app$")
public void user_is_able_to_see_calender() throws Throwable {
   helper.validateCalenderDisplayed();
}

@Then("^the calender shows current month$")
public void the_calender_shows_current_month() throws Throwable {
    helper.validateCurrentMonthIsDisplayed();
}

@Then("^user is able to see an option to add diary events to the calendar$")
public void user_is_able_to_see_an_option_to_add_diary_events_to_the_calendar() throws Throwable {
    helper.validateCreateEventOptionAvailable();
}

@Given("^able to click on months of the year and see all the days of the month$")
public void able_to_click_on_months_of_the_year() throws Throwable {
    helper.validateToClickOnMonths();
}

@When("user on create event and add required event details")
public void user_on_create_event_and_add_required_event_details() throws InterruptedException {
    helper.createEventforRequiredDate("6", "Priyanka Interview [DONE]","Priyanka Interview [DONE]","");
}
@Then("user is able to see an event is created for the required day")
public void user_is_able_to_see_an_event_is_created_for_the_required_day() throws InterruptedException {
    helper.validateEventCreatedforRequiredDate("6");
}

@Then("event is created in default colour and displayed on main page once created")
public void event_is_created_in_default_colour_and_displayed_on_main_page_once_created() throws InterruptedException {
   helper.validateEventCreatedInSpecificColourforRequiredDate("indigo","6");
}

@When("user on create event and add {string} and {string} and {string} and {string}")
public void user_on_create_event_and_add_and_and_and(String dateOfEvent, String eventTitle, String eventDescription, String colour) throws InterruptedException {
	helper.createEventforRequiredDate(dateOfEvent, eventTitle, eventDescription,colour);
}

@Then("event is created in red colour for required day")
public void event_is_created_in_red_colour() throws InterruptedException {
	 helper.validateEventCreatedInSpecificColourforRequiredDate("red","25");
}

@Given("user has multiple events added for the required day")
public void user_has_multiple_events_added_for_the_required_day() throws InterruptedException {
	helper.validateEventCreatedInSpecificColourforRequiredDate("red","25");
}
@Then("user is able to delete required number of events and able to see that events are deleted")
public void user_is_able_to_delete_required_number_of_events() {
	helper.deleteRequiredNumberOfEvents("25","red",2,"Final Interview Slot[8PM-9PM]");
}



}
