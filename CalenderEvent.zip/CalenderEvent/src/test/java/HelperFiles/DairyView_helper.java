package HelperFiles;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Wrappers.CommonWrappers;

public class DairyView_helper extends CommonWrappers {
	//Locators
	String btn_createEvent = "//button/span[contains(text(),'Create')]";
	String header_calendar = "//h1[contains(text(),'Calendar')]";
	String current_Month = "//button/span[contains(text(),'chevron_left')]/preceding::p";
    String leftArrow_Months = "//button/span[contains(text(),'Create')]/following::button/span[contains(text(),'chevron_left')]";
    String rightArrow_Months = "//button/span[contains(text(),'Create')]/following::button/span[contains(text(),'chevron_right')]";
	String cal_days_grid = "//button/span[contains(text(),'Create')]/following::div[contains(@class,'grid grid-cols-7')][1]";
	String txt_eventTitle = "//input[contains(@name,'title')]";
	String txt_eventDescription = "//input[contains(@name,'description')]";
	String ele_defaultColour = "//*[contains(@class,'bg-indigo')]";
	String dateValue = "//button[contains(@class,'py-1 w-full ')]/span[contains(@class,'text-sm')]";
	String btn_Save = "//button[@type='submit' and contains(text(),'Save')]";
	String dates_rightpane = "//div/header/p[contains(@class,'text-sm p-1 my-1 text-center  ')]"; 
	String events_added = "//div/header/p[contains(text(),9)]/following::div[contains(@class,'bg-indigo-200')]";
	String lbl_deleteEvent = "//div/span[contains(text(),'delete')]";
	String btn_close = "//button/span[contains(text(),'close')]";
	
public void validateAppLoaded () {
	verifyTitle("React App");
}

public void validateCalenderDisplayed () {
	verifyTitle("React App");
	Assert.assertTrue("App loaded successfully", findElementByXpath(btn_createEvent).isDisplayed());
}

public void validateCurrentMonthIsDisplayed() {
	LocalDate currentdate = LocalDate.now();
	Month currentMonth = currentdate.getMonth();
	System.out.println(currentMonth);
	int currentYear = currentdate.getYear();
	System.out.println(currentYear);
	
	String[] curr_mon_yr = getTextByXpath(current_Month).split(" ");
	Assert.assertTrue("Current month is getting displayed", curr_mon_yr[0].equalsIgnoreCase(currentMonth.toString()));
	Assert.assertTrue("Current year is getting displayed", curr_mon_yr[1].equalsIgnoreCase(Integer.toString(currentYear)));
	
}

public void validateCreateEventOptionAvailable() {
	Assert.assertTrue("Able to see Create event button available", findElementByXpath(btn_createEvent).isDisplayed());
}

public void validateToClickOnMonths() throws InterruptedException {
	
	String curr_mon = getTextByXpath(current_Month);
	
	JavascriptExecutor j = (JavascriptExecutor) driver;
	j.executeScript("arguments[0].click();", findElementByXpath(leftArrow_Months));
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	String prev_mon = getTextByXpath(current_Month);
	Assert.assertTrue("Able to navigate to previous month", !curr_mon.equalsIgnoreCase(prev_mon));
	
	curr_mon = getTextByXpath(current_Month);
	
	j.executeScript("arguments[0].click();", findElementByXpath(rightArrow_Months));
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	String next_mon = getTextByXpath(current_Month);
	Assert.assertTrue("Able to navigate to next month", !curr_mon.equalsIgnoreCase(next_mon));

	Assert.assertTrue("Able to see the days of the month", findElementByXpath(cal_days_grid).isDisplayed());
}

public void createEventforRequiredDate(String dateOfEvent, String eventTitle, String eventDesc, String colour) throws InterruptedException {
	
	List<WebElement> dates = findElementsByXpath(dateValue);
	System.out.println(dates.size());
	for (int i=0;i<dates.size();i++)
	{
		System.out.println(dates.get(i).getText());
		if (dates.get(i).getText().equalsIgnoreCase(dateOfEvent))
		{
			dates.get(i).click();
			clickByXpath(btn_createEvent);
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			enterByXpath(txt_eventTitle,eventTitle);
			enterByXpath(txt_eventDescription,eventDesc);
			if (colour!="" || colour!=null)
			{
				driver.findElement(By.xpath("//*[contains(@class,'bg-"+colour+"')]")).click();
			}
			clickByXpath(btn_Save);
			break;
		}
	}
}
	
	public void validateEventCreatedforRequiredDate(String dateOfEvent) throws InterruptedException {
				
		List<WebElement> datesrightpane = findElementsByXpath(dates_rightpane);
		for (int i=0;i<datesrightpane.size();i++)
		{
			System.out.println(datesrightpane.get(i).getText());
			if (datesrightpane.get(i).getText().equalsIgnoreCase(dateOfEvent)||datesrightpane.get(i).getText().equalsIgnoreCase("0"+dateOfEvent))
			{	String dateval = datesrightpane.get(i).getText();
				Assert.assertTrue("Event created successfully", driver.findElement(By.xpath("//div/header/p[contains(text(),"+dateval+")]/following::div[contains(@class,'bg-indigo-200')]")).isDisplayed());
				break;
			}
		}
}

	public void validateEventCreatedInSpecificColourforRequiredDate(String colour, String dateOfEvent) throws InterruptedException {
		
		List<WebElement> datesrightpane = findElementsByXpath(dates_rightpane);
		for (int i=0;i<datesrightpane.size();i++)
		{
			if (datesrightpane.get(i).getText().equalsIgnoreCase(dateOfEvent)||datesrightpane.get(i).getText().equalsIgnoreCase("0"+dateOfEvent))
			{	String dateval = datesrightpane.get(i).getText();
				Assert.assertTrue("Event created in colour "+colour, driver.findElement(By.xpath("//div/header/p[contains(text(),"+dateval+")]/following::div[contains(@class,'bg-"+colour+"-200')]")).isDisplayed());
				break;
			}
		}
}
	public void deleteRequiredNumberOfEvents(String dateOfEvent, String colour, int delCount, String eventTitle) {
		
		List<WebElement> eventCount = findElementsByXpath("//div/header/p[contains(text(),"+dateOfEvent+")]/following::div[contains(@class,'bg-"+colour+"-200')]");
		
		if (eventCount.size()>delCount)
		{
			for (int j=0;j<delCount;j++)
			{
				eventCount.get(j).click();
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				String event_Title = getTextByXpath(txt_eventTitle);
				if (event_Title.equalsIgnoreCase(eventTitle))
				{
					clickByXpath(lbl_deleteEvent);
					driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				}
				
				else {
				  clickByXpath(btn_close); }
				
			}
		}
		
		List<WebElement> eventCount_afterdeletion = findElementsByXpath("//div/header/p[contains(text(),"+dateOfEvent+")]/following::div[contains(@class,'bg-"+colour+"-200')]");
		Assert.assertTrue("Events are successfully deleted", eventCount_afterdeletion.size()<delCount);
		quitBrowser();
}
	
}